
from fastapi import FastAPI, Request
from pydantic import BaseModel
import uvicorn
import requests

app = FastAPI()

API_KEY = "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"

class Block(BaseModel):
    id: str
    type: str
    input: str = ""
    input_from: str = ""
    language: str = "English"

class WorkflowRequest(BaseModel):
    blocks: list[Block]

outputs = {}

def call_openrouter(prompt, model="openrouter/deepseek-chat"):
    response = requests.post(
        "https://openrouter.ai/api/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost",
            "X-Title": "PythonFlowAI"
        },
        json={
            "model": model,
            "messages": [{"role": "user", "content": prompt}]
        }
    )
    data = response.json()
    return data["choices"][0]["message"]["content"]

@app.post("/run")
def run_workflow(workflow: WorkflowRequest):
    outputs.clear()
    result = []

    for block in workflow.blocks:
        if block.input_from:
            input_val = outputs.get(block.input_from, "")
        else:
            input_val = block.input

        if block.type == "prompt":
            out = input_val
        elif block.type == "summarizer":
            out = call_openrouter("Summarize this:\n" + input_val)
        elif block.type == "translator":
            out = call_openrouter(f"Translate to {block.language}:\n" + input_val)
        elif block.type == "output":
            out = input_val
        else:
            out = f"[Unknown block type: {block.type}]"

        outputs[block.id] = out
        result.append({ "id": block.id, "output": out })

    return { "result": result }
